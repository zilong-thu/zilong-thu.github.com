
/**
 * Module dependencies.
 */

var express = require('express');
var routes = require('./routes');
var user   = require('./models/user')
var http = require('http');
var path = require('path');
var flash = require('connect-flash');

var settings = require('./settings');
var MongoStore = require('connect-mongo')(express);

var app = express();

// all environments
app.configure(function(){
  app.set('views', path.join(__dirname, 'views'));
  app.set('view engine', 'ejs');
  var partials = require('express-partials');
  app.use(partials());
  app.use(flash());

  app.use(express.favicon());
  app.use(express.json());
  app.use(express.urlencoded());
  app.use(express.methodOverride());
  app.use(express.cookieParser());
  app.use(express.session({
      secret: settings.cookieSecret,
      store: new MongoStore({
        db: settings.db
      })
  }));
  app.use(function(req, res, next){
      res.locals.user = req.session.user;
      res.locals.error = req.flash('error');
      res.locals.success = req.flash('success');
      next();
  });
});

app.configure('development', function(){
  app.use(express.errorHandler({ dumpExceptions: true, showStack: true }));
});

app.configure('production', function(){
  app.use(express.errorHandler());
});

app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));

routes(app);
app.listen(3000);
console.log('Express server listening on port 3000');
